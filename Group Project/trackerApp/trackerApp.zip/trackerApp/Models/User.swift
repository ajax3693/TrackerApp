//
//  User.swift
//  trackerApp
//
//  Created by AJ Cardoza on 11/6/23.
//

import Foundation
